﻿

//OPOA.cookieLast =false;
//从DOM的href属性读取url
OPOA.Configs.url = "href";
// 从服务器返回的内容中，提取#content的html内容显示
OPOA.Configs.find = "#content";
// 如果find指定的#content未找到，则显示所有内容
OPOA.Configs.notFound = "all";
// 加载提示处理
OPOA.Configs.loading = {
	// ajax请求开始
	"start" : function() {
		$("#contentDIV").html("");
		$("#loadingDIV").show();
	},
	// ajax请求成功
	"success" : function() {
		$("#loadingDIV").hide();
	},
	"error" : function() {
		$("#contentDIV").html("<h2>对不起，请求发生错误！请稍后再试。</h2>");
	},
	// ajax请求结束（无论成功失败都会调用）
	"end" : function(hash) {
		$("#loadingDIV").hide();
		

		 // 加载完某个请求后，对请求页面的Hash动作实例初始化
		 // 查看列表
		 if(hash.indexOf("list")!=-1){
			 //opoa实例
			 var opoa={
				 "actions":"#show A[hash]",
				 "show":"#contentDIV"
			 };
								
			 EasyOPOA.start([opoa]);
			 
			
		 }
		 //显示菜单
		showMenu();
	}
};

// HTTP代码处理
OPOA.Configs.urlErrors = {
	// 404 HTTP代码
	404 : function() {
		$("#contentDIV").html("<h2>404，对不起，您请求的页面没有找到！可能已失效。</h2>");
	},
	// 500 HTTP代码
	500 : function() {
		$("#contentDIV").html("<h2>500，对不起，服务器错误！请稍后再试。</h2>");
	}
};
// opoa实例
var opoa = {
	"actions" : "#menuDIV .menu",
	"show" : "#contentDIV"
};
EasyOPOA.notHash = function() {
	$("#loadingDIV").hide();
	// 显示欢迎页面
	OPOA.load("welcome");
};

// 注册Home页面的有参Hash动作
EasyOPOA.addActionMap("list/:pageNo", "list.jsp?pageNo={pageNo}", opoa);
// 注册子页面的有参Hash动作
EasyOPOA.addActionMap("show/:id", "show.jsp?pageNo=1&id={id}", opoa);
EasyOPOA.addActionMap("edit/:id", "edit.jsp?pageNo=1&id={id}", opoa);
EasyOPOA.addActionMap("delete/:id", "do/doDelete.jsp?pageNo=1&id={id}", opoa);

EasyOPOA.addActionMap("show/:pageNo/:id", "show.jsp?pageNo={pageNo}&id={id}", opoa);
EasyOPOA.addActionMap("edit/:pageNo/:id", "edit.jsp?pageNo={pageNo}&id={id}", opoa);
EasyOPOA.addActionMap("delete/:pageNo/:id", "do/doDelete.jsp?pageNo={pageNo}&id={id}", opoa);


//修改表单提交
EasyOPOA.addActionMap("doEdit", "do/doEdit.jsp", opoa);
EasyOPOA.addActionMap("doAdd", "do/doAdd.jsp", opoa);

//url,opoa,postData
//EasyOPOA.homeUrl("welcome.jsp", opoa);
//hash,postData
EasyOPOA.home("welcome");

// opoa实例数组集合
var opoaList = [ opoa ];
// 使用opoaList启动
EasyOPOA.start(opoaList);





//处理显示的菜单
var oldMenu = $("#menuDIV [class~='nowMenu']");

function showMenu() {
	var welcomeMenu=/.*welcome.*/g;
	var listMenu=/.*list.*|.*show.*|.*edit.*|.*doEdit.*|.*doDelete.*/g;
	var addMenu=/.*add.*/g;
	var aboutMenu=/.*about.*/g;
	
	var hash = window.location.hash;
	var nowMenu = $("#menuDIV [class~='defaultMenu']");
	if (hash) {
		hash=hash.substring(1);
		
		if(welcomeMenu.test(hash)){
			nowMenu= $("#menuDIV [hash='welcome']");
		}else if(listMenu.test(hash)){
			nowMenu= $("#menuDIV [hash='list']");
		}else if(addMenu.test(hash)){
			nowMenu= $("#menuDIV [hash='add']");
		}else if(aboutMenu.test(hash)){
			nowMenu= $("#menuDIV [hash='about']");
		}
		

	} else {
		nowMenu= $("#menuDIV [hash='welcome']");
	}
	oldMenu.removeClass("nowMenu");
	nowMenu.addClass("nowMenu");
	oldMenu = nowMenu;
}

$(function() {
	// show default menu
	showMenu();
	// Menu click change
	$("#menuDIV [class~='menu']").on("click", function() {
		var old = $("#menuDIV [class~='nowMenu']");
		oldMenu.removeClass("nowMenu");
		oldMenu = $(this);
		oldMenu.addClass("nowMenu");
	});
	$("#menuDIV [class~='menu']").on("focus", function() {
		this.blur();
	});

});